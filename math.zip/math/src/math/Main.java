package math;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String operacion;

        while (true) {
            System.out.print("> Introduce un comando: ");
            operacion = scanner.nextLine().trim();

            if (operacion.equalsIgnoreCase("F")) {
                break;
            }

            procesarOperacion(operacion);
        }

        scanner.close();
    }

    private static void procesarOperacion(String operacion) {
        String[] partes = operacion.trim().split("\\s+");

        if (partes.length != 3) {
            System.out.println("Formato incorrecto");
            return;
        }

        char tipoOperacion = partes[0].charAt(0);
        Complex num1 = createComplex(partes[1]);
        Complex num2 = createComplex(partes[2]);

        if (num1 == null || num2 == null) {
            System.out.println("Números complejos inválidos");
            return;
        }

        Complex resultado = null;

        switch (tipoOperacion) {
            case '+':
                resultado = num1.add(num2);
                break;
            case '-':
                resultado = num1.resta(num2);
                break;
            case '*':
                resultado = num1.mult(num2);
                break;
            case '/':
                resultado = num1.divide(num2);
                break;
            default:
                System.out.println("Operación no reconocida");
                return;
        }

        System.out.println(resultado.toString());
    }

    private static Complex createComplex(String strComplex) {
        strComplex = strComplex.substring(1, strComplex.length() - 1);
        String[] valores = strComplex.split(",");

        if (valores.length != 2) {
            return null;
        }

        try {
            double real = Double.parseDouble(valores[0].trim());
            double imaginario = Double.parseDouble(valores[1].trim());
            return new Complex(real, imaginario);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
