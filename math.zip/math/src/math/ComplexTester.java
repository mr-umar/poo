package math;

public class ComplexTester {

    public static void main(String[] args) {
        Complex c1 = new Complex(3, 4);
        System.out.println("c1: " + c1.toString());  

        Complex c2 = new Complex(c1);
        System.out.println("c2 (copia de c1): " + c2.toString());  

        System.out.println("Parte real de c1: " + c1.getReal());  
        System.out.println("Parte imaginaria de c1: " + c1.getIm());  

        c1.setReal(5);
        c1.setIm(-2);
        System.out.println("c1 después de set: " + c1.toString()); 

        Complex c3 = new Complex(1, 1);
        Complex suma = c1.add(c3);
        System.out.println("Suma de c1 y c3: " + suma.toString());  

        Complex resta = c1.resta(c3);
        System.out.println("Resta de c1 y c3: " + resta.toString()); 
        
        Complex mult = c1.mult(c3);
        System.out.println("Multiplicación de c1 y c3: " + mult.toString());  

        Complex div = c1.divide(c3);
        System.out.println("División de c1 entre c3: " + div.toString()); 

        System.out.println("Módulo de c1: " + c1.getModulo());  
        System.out.println("Fase de c1 en radianes: " + c1.getFase()); 
    }

}
