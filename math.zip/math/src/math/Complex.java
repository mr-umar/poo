package math;

public class Complex {
    private double real;
    private double imaginary;

    public Complex(double r, double im) {
        this.real = r;
        this.imaginary = im;
    }
    
    public Complex(Complex c) {
        this.real = c.real;
        this.imaginary = c.imaginary;
    }
    
    public double getReal() {
        return real;
    }
    
    public double getIm() {
        return imaginary;
    }
    
    public void setReal(double r) {
        this.real = r;
    }
    
    public void setIm(double im) {
        this.imaginary = im;
    }
    
    public Complex add(Complex c) {
        return new Complex(this.real + c.real, this.imaginary + c.imaginary);
    }
    
    public Complex resta(Complex c) {
        return new Complex(this.real - c.real, this.imaginary - c.imaginary);
    }
    
    public Complex mult(Complex c) {
        double r = this.real * c.real - this.imaginary * c.imaginary;
        double im = this.real * c.imaginary + this.imaginary * c.real;
        return new Complex(r, im);
    }
    
    public Complex divide(Complex c) {
        double denominator = c.real * c.real + c.imaginary * c.imaginary;
        double r = (this.real * c.real + this.imaginary * c.imaginary) / denominator;
        double im = (this.imaginary * c.real - this.real * c.imaginary) / denominator;
        return new Complex(r, im);
    }
    
    public double getModulo() {
        return Math.sqrt(this.real * this.real + this.imaginary * this.imaginary);
    }
    
    public double getFase() {
        return Math.atan2(this.imaginary, this.real);
    }
   
    @Override
    public String toString() {
        if (imaginary >= 0) {
            return real + "+" + imaginary + "j";
        } else {
            return real + "" + imaginary + "j";
        }
    }
}