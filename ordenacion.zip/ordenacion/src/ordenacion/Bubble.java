package ordenacion;

public class Bubble {
    public static void sort(int[] a) {
        boolean intercambiado;

        for (int i = 0; i < a.length - 1; i++) {
            intercambiado = false;

            for (int j = 0; j < a.length - 1 - i; j++) {
                if (a[j] > a[j + 1]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                    intercambiado = true;
                }
            }
            
            if (!intercambiado)
                break;
            
        }
    }

    public static void imprimirArray(int[] a) {
        for (int num : a) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] nums = {10, 3, 7, 6, 9, 8, 7, 1};

        System.out.println("Array SIN ordenar:");
        imprimirArray(nums);

        sort(nums);

        System.out.println("Array ordenado:");
        imprimirArray(nums);
    }
}