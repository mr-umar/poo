package ordenacion;

public class Insertion {

    // meotodo de ordenado
    public static void sort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int ref = a[i];
            int j = i - 1;

            while (j >= 0 && a[j] > ref) {
                a[j + 1] = a[j];
                j--;
            }

            a[j + 1] = ref;
        }
    }

    public static void imprimirArray(int[] a) {
        for (int num : a) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] nums = {30, 15, 2, 21, 44, 8};
        
        // print array sin ordenar
        System.out.println("Array SIN ordenar:");
        imprimirArray(nums);
        
        // ejecución del método
        sort(nums);

        // print array ordenado
        System.out.println("Array ordenado:");
        imprimirArray(nums);
    }
}
