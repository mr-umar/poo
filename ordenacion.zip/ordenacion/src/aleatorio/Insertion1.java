package aleatorio;

import java.util.Random;

public class Insertion1 {

    // meotodo de ordenado
    public static void sort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int ref = a[i];
            int j = i - 1;

            while (j >= 0 && a[j] > ref) {
                a[j + 1] = a[j];
                j--;
            }

            a[j + 1] = ref;
        }
    }

    public static void imprimirArray(int[] a) {
        for (int num : a) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        
        int[] nums = new int[10]; 
        Random random = new Random();

        for (int i = 0; i < nums.length; i++) {
            nums[i] = random.nextInt(100); 
        }

        System.out.println("Array SIN ordenar:");
        imprimirArray(nums);

        sort(nums);

        System.out.println("Array ordenado:");
        imprimirArray(nums);
    }
}
