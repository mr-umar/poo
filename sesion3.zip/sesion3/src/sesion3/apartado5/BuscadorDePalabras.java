package sesion3.apartado5;

import java.util.Scanner;

public class BuscadorDePalabras {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Uso de String 
        String frase = "Java Python C++ JavaScript HTML CSS";
        String palabraBuscada = "Python";

        // Mostrar búsqueda con valores fijos
        System.out.println("Buscando en la frase fija: " + frase);
        buscarPalabra(frase, palabraBuscada);

        // Leer desde teclado
        System.out.print("\nIntroduce una frase: ");
        String fraseUsuario = scanner.nextLine();

        System.out.print("Introduce la palabra a buscar: ");
        String palabraUsuario = scanner.nextLine();

        // Buscar palabra del usuario
        buscarPalabra(fraseUsuario, palabraUsuario);

        scanner.close();
    }


    public static void buscarPalabra(String frase, String palabra) {
        String[] palabras = frase.split(" ");

        boolean encontrada = false;
        for (String p : palabras) {
            if (p.equals(palabra)) { 
                encontrada = true;
                break;
            }
        }

        if (encontrada) {
            System.out.println("La palabra \"" + palabra + "\" se encuentra en la frase.");
        } else {
            System.out.println("La palabra \"" + palabra + "\" NO se encuentra en la frase.");
        }
    }
}