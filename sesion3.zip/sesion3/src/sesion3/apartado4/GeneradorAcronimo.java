package sesion3.apartado4;

import java.util.Scanner;


public class GeneradorAcronimo {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.print("Introduce una frase: ");
        String frase = lector.nextLine();

        String acronimo = generarAcronimo(frase);
        
        System.out.println("El acrónimo: " + acronimo);
        
        lector.close();
    }

    public static String generarAcronimo(String frase) {
        String[] palabras = frase.split(" ");
         
        StringBuilder acronimo = new StringBuilder();
        
        for (String palabra : palabras) {
            if (!palabra.isEmpty()) {
                acronimo.append(palabra.charAt(0));
            }
        }
        
        return acronimo.toString().toUpperCase();
    }
}