
import java.util.Scanner;

public class SaludarNom {

    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        System.out.print("Com et dius? ");
        String text = lector.nextLine();
        System.out.println("Hola " + text + "!");
    }
}
