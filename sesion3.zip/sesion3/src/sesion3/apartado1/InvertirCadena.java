package sesion3.apartado1;

public class InvertirCadena {
    public static void main(String[] args) {
        String texto = "Escola Tècnica Superior Enginyeria Telecomunicació Barcelona";

        String invertido1 = "";
        for (int i = texto.length() - 1; i >= 0; i--) {
            invertido1 += texto.charAt(i);
        }
        invertido1 = invertido1.toLowerCase(); 
        System.out.println("Usando String y '+': " + invertido1);

        StringBuilder sb = new StringBuilder(texto);
        String invertido2 = sb.reverse().toString().toLowerCase();
        System.out.println("Usando StringBuilder: " + invertido2);
    }
}