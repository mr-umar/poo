package mdc;

import java.util.Scanner;


public class mdc_recursivo {
    
    public static int mcd(int a, int b) {
        if (b == 0) {
            return a;
        } 
        
        return mcd(b, a % b);
        
    }

    public static void main(String[] args) {
        System.out.println("Introduce dos números: ");
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        System.out.println("El MCD " + a + " y " + b + " es " + mcd(a, b));
        
        
        
        
    }

}