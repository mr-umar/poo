package contenedores;

public class Trabajo {
    private int id;
    private String usuario;
    private String descripcion;
    
    public Trabajo(int id, String usuario, String descripcion) {
        this.id = id;
        this.usuario = usuario;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public String getUsuario() {
        return usuario;
    }

    @Override
    public String toString() {
        return "ID: " + id + " [" + usuario + "]: " + descripcion;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Trabajo)) {
            return false;
        }
        Trabajo trabajo = (Trabajo) o;
        return this.id == trabajo.id &&
               this.usuario.equals(trabajo.usuario) &&
               this.descripcion.equals(trabajo.descripcion);
    }

    @Override
    public int hashCode() {
        return (id + usuario + descripcion).hashCode();
    }
}
