package contenedores;

import java.util.HashSet;

public class Tests {

    public static void main(String[] args) {
        juegoPruebasTrabajoImpresora1();
        juegoPruebasTrabajoImpresora2();
        juegoPruebasOficina();
        juegoPruebasConjuntos1();
        juegoPruebasConjuntos2();
    }

    public static void juegoPruebasTrabajoImpresora1() {
        System.out.println("=== Juego de Pruebas Trabajo e Impresora 1 ===");

        Impresora impresora = new Impresora("LaserPrinter-1");

        Trabajo t1 = new Trabajo(1, "User-1", "documento.docx");
        Trabajo t2 = new Trabajo(2, "User-12", "listado.pdf");
        Trabajo t3 = new Trabajo(3, "User-7", "horario.docx");
        Trabajo t4 = new Trabajo(4, "User-1", "libro java.pdf");
        Trabajo t5 = new Trabajo(5, "User-3", "nomina.pdf");
        Trabajo t6 = new Trabajo(6, "User-3", "tareas.txt");

        impresora.addTrabajoEnCola(t1);
        impresora.addTrabajoEnCola(t2);
        impresora.addTrabajoEnCola(t3);
        impresora.addTrabajoEnCola(t4);
        impresora.addTrabajoEnCola(t5);
        impresora.addTrabajoEnCola(t6);


        System.out.println(impresora);

        impresora.procesaSiguienteTrabajo();
        impresora.procesaSiguienteTrabajo();

  
        System.out.println(impresora);
    }

    public static void juegoPruebasTrabajoImpresora2() {
        System.out.println("=== Juego de Pruebas Trabajo e Impresora 2 ===");

        Impresora impresora = new Impresora("LaserPrinter-1");


        Trabajo t1 = new Trabajo(1, "User-1", "documento.docx");
        Trabajo t2 = new Trabajo(2, "User-12", "listado.pdf");
        Trabajo t3 = new Trabajo(3, "User-7", "horario.docx");
        Trabajo t4 = new Trabajo(4, "User-1", "libro java.pdf");
        Trabajo t5 = new Trabajo(5, "User-3", "nomina.pdf");
        Trabajo t6 = new Trabajo(6, "User-3", "tareas.txt");


        impresora.addTrabajoEnCola(t1);
        impresora.addTrabajoEnCola(t2);
        impresora.addTrabajoEnCola(t3);
        impresora.addTrabajoEnCola(t4);
        impresora.addTrabajoEnCola(t5);
        impresora.addTrabajoEnCola(t6);


        System.out.println(impresora);


        impresora.priorizaTrabajoEnCola(6);


        impresora.limitaLongitudCola(3);

        System.out.println(impresora);
    }


    public static void juegoPruebasOficina() {
        System.out.println("=== Juego de Pruebas Oficina ===");

        Oficina oficina = new Oficina();


        oficina.nuevaImpresora("LaserPrinter-1");
        oficina.nuevaImpresora("LaserPrinter-2");
        oficina.nuevaImpresora("LaserPrinter-3");


        Trabajo t1 = new Trabajo(1, "User-1", "documento.docx");
        Trabajo t2 = new Trabajo(2, "User-12", "listado.pdf");
        Trabajo t3 = new Trabajo(3, "User-7", "horario.docx");
        Trabajo t4 = new Trabajo(4, "User-1", "libro java.pdf");
        Trabajo t5 = new Trabajo(5, "User-3", "nomina.pdf");
        Trabajo t6 = new Trabajo(6, "User-3", "tareas.txt");


        oficina.addTrabajoImpresora("LaserPrinter-1", t1);
        oficina.addTrabajoImpresora("LaserPrinter-1", t2);
        oficina.addTrabajoImpresora("LaserPrinter-2", t3);
        oficina.addTrabajoImpresora("LaserPrinter-2", t4);
        oficina.addTrabajoImpresora("LaserPrinter-3", t5);
        oficina.addTrabajoImpresora("LaserPrinter-3", t6);


        System.out.println(oficina.getInfoImpresoras());


        System.out.println(oficina.nuevaImpresora("LaserPrinter-1")); // Debe devolver false


        System.out.println(oficina.addTrabajoImpresora("NonExistentPrinter", t1)); // Debe devolver IMPRESORA_NO_EXISTE


        System.out.println(oficina.procesaTrabajoImpresora("NonExistentPrinter")); // Debe devolver IMPRESORA_NO_EXISTE


        System.out.println(oficina.procesaTrabajoImpresora("LaserPrinter-1")); // Debe devolver OK_ACTION
        System.out.println(oficina.procesaTrabajoImpresora("LaserPrinter-1")); // Debe devolver OK_ACTION
        System.out.println(oficina.procesaTrabajoImpresora("LaserPrinter-1")); // Debe devolver TRABAJO_NO_EXISTE


        System.out.println(oficina.getInfoImpresoras());
    }


    public static void juegoPruebasConjuntos1() {
        System.out.println("=== Juego de Pruebas Conjuntos 1 ===");

        Oficina oficina = new Oficina();


        oficina.nuevaImpresora("LaserPrinter-A");
        oficina.nuevaImpresora("LaserPrinter-B");


        oficina.addTrabajoImpresora("LaserPrinter-A", new Trabajo(1, "Juan", "doc1.pdf"));
        oficina.addTrabajoImpresora("LaserPrinter-A", new Trabajo(2, "Ana", "doc2.pdf"));
        oficina.addTrabajoImpresora("LaserPrinter-B", new Trabajo(3, "Juan", "doc3.pdf"));
        

        oficina.muestraUsuariosActualmenteImprimiendo();
    }


    public static void juegoPruebasConjuntos2() {
        System.out.println("=== Juego de Pruebas Conjuntos 2 ===");

        HashSet<Trabajo> conjuntoTrabajos = new HashSet<>();


        Trabajo t1 = new Trabajo(1, "User-A", "archivoA.txt");
        Trabajo t2 = new Trabajo(2, "User-B", "archivoB.txt");
        Trabajo t3 = new Trabajo(1, "User-A", "archivoA.txt"); 


        conjuntoTrabajos.add(t1);
        conjuntoTrabajos.add(t2);
        conjuntoTrabajos.add(t3); 

        for (Trabajo trabajo : conjuntoTrabajos) {
            System.out.println(trabajo);
        }
    }
}

