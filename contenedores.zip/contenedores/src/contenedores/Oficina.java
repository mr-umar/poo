package contenedores;

import java.util.HashMap;
import java.util.HashSet;

public class Oficina {
    private HashMap<String, Impresora> impresoras;

    public Oficina() {
        impresoras = new HashMap<>();
    }

    public boolean nuevaImpresora(String nombre) {
        if (impresoras.containsKey(nombre)) {
            return false;
        }
        impresoras.put(nombre, new Impresora(nombre));
        return true;
    }

    public int addTrabajoImpresora(String nombre, Trabajo trabajo) {
        Impresora impresora = impresoras.get(nombre);
        if (impresora == null) {
            return -1; // IMPRESORA_NO_EXISTE
        }
        impresora.addTrabajoEnCola(trabajo);
        return 0; // OK_ACTION
    }

    public int procesaTrabajoImpresora(String nombre) {
        Impresora impresora = impresoras.get(nombre);
        if (impresora == null) {
            return -1; // IMPRESORA_NO_EXISTE
        }
        if (!impresora.procesaSiguienteTrabajo()) {
            return -2; // TRABAJO_NO_EXISTE
        }
        return 0; // OK_ACTION
    }

    public String getInfoImpresoras() {
        if (impresoras.isEmpty()) {
            return "No se ha encontrado ninguna impresora.";
        }
        
        StringBuilder sb = new StringBuilder();
        
        for (Impresora impresora : impresoras.values()) {
            sb.append(impresora.toString()).append("\n");
        }
        
        return sb.toString();
    }

    public void muestraUsuariosActualmenteImprimiendo() {
        HashSet<String> usuarios = new HashSet<>();
        
        for (Impresora impresora : impresoras.values()) {
            for (Trabajo trabajo : impresora.getCola()) { 
                usuarios.add(trabajo.getUsuario());
            }
        }

        System.out.println("Usuarios actualmente imprimiendo: " + usuarios);
    }
}
