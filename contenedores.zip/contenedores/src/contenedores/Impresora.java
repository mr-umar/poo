package contenedores;

import java.util.LinkedList;

public class Impresora {
    private String nombre;
    private LinkedList<Trabajo> cola;

    public Impresora(String nombre) {
        this.nombre = nombre;
        this.cola = new LinkedList<>();
    }

    public void addTrabajoEnCola(Trabajo trabajo) {
        cola.addLast(trabajo);
    }

    public boolean procesaSiguienteTrabajo() {
        if (!cola.isEmpty()) {
            cola.removeFirst();
            return true;
        }
        return false;
    }

    public boolean priorizaTrabajoEnCola(int id) {
        for (int i = 0; i < cola.size(); i++) {
            if (cola.get(i).getId() == id) {
                Trabajo trabajo = cola.remove(i);
                cola.addFirst(trabajo);
                return true;
            }
        }
        return false;
    }

    public void limitaLongitudCola(int maxTrabajos) {
        while (cola.size() > maxTrabajos) {
            cola.removeLast();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Impresora: " + nombre + "\nTrabajos en cola:\n");
        for (Trabajo trabajo : cola) {
            sb.append("\t").append(trabajo.toString()).append("\n");
        }
        return sb.toString();
    }
    
    public LinkedList<Trabajo> getCola() {
    return new LinkedList<>(cola); 
}

}
